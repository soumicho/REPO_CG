#!/bin/bash

source ./conf.txt


# Function to delete old files
cleanup_dir() {
    local dir=$1
    local retention_days=$2
    local description=$3

    echo "Cleaning up $description files in $dir older than $retention_days days" >> $HOUSEKEEPING_LOG
    find $dir -type f -mtime +$retention_days -exec rm -f {} \;
}

# Function to clear old core dumps
cleanup_core_dumps() {
    echo "Cleaning up core dump files" >> $HOUSEKEEPING_LOG
    find / -name "core" -type f -exec rm -f {} \;
}

# Start housekeeping
echo "Starting SAP OS housekeeping - $(date)" >> $HOUSEKEEPING_LOG

# Clean log files
cleanup_dir $DIR_LOG $RETENTION_DAYS "log"

# Clean work files
cleanup_dir $DIR_WORK $RETENTION_DAYS "work"

# Clean global directory (if applicable)
cleanup_dir $DIR_GLOBAL $RETENTION_DAYS "global"

# Clean temporary files
cleanup_dir $DIR_TEMP $RETENTION_DAYS "temporary"

# Clean up old core dumps
cleanup_core_dumps

# End housekeeping
echo "Housekeeping completed - $(date)" >> $HOUSEKEEPING_LOG

# Rotate logs if necessary (optional)
logrotate /etc/logrotate.d/sap_housekeeping

# Exit
exit 0
