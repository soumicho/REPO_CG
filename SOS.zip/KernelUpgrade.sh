#!/bin/bash

source conf.txt
sidadm=$(whoami)
details=$(sapcontrol -nr $ASCS -function GetSystemInstanceList | grep GREEN | awk -F, '{print $1 " " $2}')

if (( sapcontrol -nr $ascs -function GetProcessList ) | grep -q "msg_server"); then
    ./SAPCAR.EXE -xvf $kernel_location
    ./SAPCAR.EXE -xvf $kernel_db_location

    cd $kernel_location/SAPEXE_.*.
    chown -R <sid>adm:sapsys *
    chmod -R 755 *

    cp -pr * $(cdexe)

    cd $kernel_db_location/SAPEXEDB_*.*
    chown -R <sid>adm:sapsys *
    chmod -R 755 *

    cp -pr * $(cdexe)

    while IFS= read -r line; do
        host=$(echo $line | awk '{print $1}')
        instance=$(echo $line | awk '{print $2}')
        ssh $sidadm@$host sapcontrol -nr $instance -function UpdateSystem <waittimeout sec> <softtimeout sec>
        # sapcontrol -nr $instance -function UpdateSystem <waittimeout sec> <softtimeout sec>
    done <<< "$details"

    while IFS= read -r line; do
        host=$(echo $line | awk '{print $1}')
        instance=$(echo $line | awk '{print $2}')
        ./serverIsStarted.sh $instance $sidadm@$host 
    done <<< "$details"
else
    echo "ASCS details incorrect."
fi