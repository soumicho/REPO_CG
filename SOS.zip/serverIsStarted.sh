sidadm=$(whoami)
details=$(sapcontrol -nr $1 -function GetSystemInstanceList | grep GREEN | awk -F, '{print $1 " " $2}')

if (( sapcontrol -nr $1 -function GetProcessList ) | grep -q "msg_server"); then

    while IFS= read -r line; do
        host=$(echo $line | awk '{print $1}')
        instance=$(echo $line | awk '{print $2}')
        status=$(ssh $sidadm@$host sapcontrol -nr $instance -function GetProcessList)
        SECONDS=0
        while (( echo $status | grep -q "YELLOW" ) || ( echo $status | grep -q "GRAY" ));do
            if [[ $SECONDS < 300 ]]; then 
                echo "ERROR"
            fi
            sleep 5
            status=$(ssh $sidadm@$host sapcontrol -nr $instance -function GetProcessList)
        done
    done <<< "$details"
else
    echo "ASCS details incorrect."
fi