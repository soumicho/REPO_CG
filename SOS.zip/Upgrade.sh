#!/bin/bash

source ./conf.txt
# sidadm=$(whoami)
################### main function########################################################
main(){
while :
 do
 clear
 echo "----------------------------------------------"
echo " * * * * * * * Main Menu * * * * * * * * * * "
 echo "----------------------------------------------"
 echo "[1] Execute Stop SAP"
 echo "[2] Execute Rolling Kernel Upgrade"
 echo "[3] Execute Start SAP"
 echo "[4] Execute Host Agent Upgrade"
 echo "[5] Execute Diagnostic Agent Upgrade"
 echo "[6] Exit/stop"
 echo "----------------------------------------------"
echo -n "Enter your menu choice [1-6]:"
 read yourch
 case $yourch in
 1) echo "Stop SAP" ; StopSAP;;
 2) echo "Start SAP" ; startSAP;; 
 3) echo "Rolling Kernel Upgrade" ; kernelUpgrade;;
 4) echo "Host Agent Upgrade" ; hostAgentUpdate ;;
 5) echo "Diagnostic Agent Upgrade" ; diagnosticAgentUpdate ;;
 6) exit 0 ;;
 *) echo "Opps!!! Please select choice [1-6]";
 echo "Press a key. . ." ; read ;;
esac
done

}

serverIsStopped() {
    ./serverIsStopped $ascs
}

serverIsStarted() {
    ./serverIsStarted.sh $ascs
}

stopSAP() {
    ./startSAP.sh $ascs
}

startSAP() {
    ./startSAP.sh $ascs
}

kernelUpgrade() {
    ./KernelUpgrade.sh $ascs
}

hostAgentUpdate() {
    ./hostAgentUpdate.sh
}

diagnosticAgentUpdate() {
    while read server; do
        ssh server
        echo "Enter the platform details"
        read Platform
        echo "Enter the DASID"
        read DASID
        echo "Enter the SMDA instance number"
        read SMDA_NUMBER
        stopSAP
        while read instanceNumber;do
        cleanipc $instanceNumber remove
        mv /usr/sap/$DASID/SYS/exe/uc/$Platform /usr/sap/$DASID/SYS/exe/uc/$Platform_old
        rm -rf /usr/sap/$DASID/SYS/exe/uc/$Platform/*
        SAPCAR -xvf UpgradeFiles/DiagnosticsAgent/SAPEXE.SAR /usr/sap/$DASID/SYS/exe/uc/$Platform
        mv /usr/sap/$DASID/SMDA$SMDA_NUMBER/exe /usr/sap/$DASID/SMDA$SMDA_NUMBER/exe_old
        rm -rf /usr/sap/$DASID/SMDA$SMDA_NUMBER/exe/*
        cp -pr /usr/sap/$DASID/SMDA$SMDA_NUMBER/exe_old/sapjvm* /usr/sap/$DASID/SMDA$SMDA_NUMBER/exe
        cd /usr/sap/$DASID/SMDA$SMDA_NUMBER/work
        sapcpe pf=/usr/sap/$DASID/SYS/profile/$DASID _SMDA$SMDA_NUMBER_<hostname>
        done < instanceNumbers.txt
        startSAP
    done < SSH_Details.txt
}

main