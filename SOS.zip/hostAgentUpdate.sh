#!/bin/bash

sidadm=$(whoami)
details=$(sapcontrol -nr $1 -function GetSystemInstanceList | grep GREEN | awk -F, '{print $1 " " $2}')

if (( sapcontrol -nr $1 -function GetProcessList ) | grep -q "msg_server"); then

    while IFS= read -r line; do
        host=$(echo $line | awk '{print $1}')
        instance=$(echo $line | awk '{print $2}')
        ssh $sidadm@$PAS_server saphostexec -upgrade -archive $host_agent_location
    done <<< "$details"

else
    echo "ASCS details incorrect."
fi