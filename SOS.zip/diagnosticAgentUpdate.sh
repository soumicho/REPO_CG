#!/bin/bash

source conf.txt

sidadm=$(whoami)
details=$(sapcontrol -nr $1 -function GetSystemInstanceList | grep GREEN | awk -F, '{print $1 " " $2}')

if (( sapcontrol -nr $1 -function GetProcessList ) | grep -q "msg_server"); then

    ./stopSAP.sh $ascs
    while IFS= read -r line; do
        host=$(echo $line | awk '{print $1}')
        instance=$(echo $line | awk '{print $2}')
        ssh $sidadm@$host cleanipc $instance remove
        ssh $sidadm@$host mv /usr/sap/$DAAADM/SYS/exe/uc/$Platform /usr/sap/$DAAADM/SYS/exe/uc/$Platform_old
        ssh $sidadm@$host rm -rf /usr/sap/$DAAADM/SYS/exe/uc/$Platform/*
        ssh $sidadm@$host SAPCAR -xvf UpgradeFiles/DiagnosticsAgent/SAPEXE.SAR /usr/sap/$DAAADM/SYS/exe/uc/$Platform
        ssh $sidadm@$host mv /usr/sap/$DAAADM/SMDA$SMDA_NUMBER/exe /usr/sap/$DAAADM/SMDA$SMDA_NUMBER/exe_old
        ssh $sidadm@$host rm -rf /usr/sap/$DAAADM/SMDA$SMDA_NUMBER/exe/*
        ssh $sidadm@$host cp -pr /usr/sap/$DAAADM/SMDA$SMDA_NUMBER/exe_old/sapjvm* /usr/sap/$DAAADM/SMDA$SMDA_NUMBER/exe
        ssh $sidadm@$host cd /usr/sap/$DAAADM/SMDA$SMDA_NUMBER/work
        ssh $sidadm@$host sapcpe pf=/usr/sap/$DAAADM/SYS/profile/$DAAADM _SMDA$SMDA_NUMBER_<hostname>
    done <<< "$details"
    startSAP.sh $ascs

else
    echo "ASCS details incorrect."
fi


# PATH For DAASID /usr/sap/DAA/SMDA98/exe/