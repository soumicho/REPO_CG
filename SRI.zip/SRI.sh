#!/bin/bash
#echo "Hello"
#set -vx

########################Variable declaration##########################
#SAPSYSTEMNAME=SHD
#dirpath=moninfo/sapinstauto
#input_file="/sapmnt/$SAPSYSTEMNAME/$dirpath/inifile_list"
#rep_file="/sapmnt/$SAPSYSTEMNAME/moninfo/inifile.params"
#rep_file="/sapmnt/$SAPSYSTEMNAME/$dirpath/inifile_tmp.params"
#prod_file="/sapmnt/$SAPSYSTEMNAME/$dirpath/prodinfo.txt"
#ascs_tmplate="/sapmnt/$SAPSYSTEMNAME/$dirpath/inifile_ascs.params"
#db_tmplate="/sapmnt/$SAPSYSTEMNAME/$dirpath/inifile_db.params"
#pas_tmplate="/sapmnt/$SAPSYSTEMNAME/$dirpath/inifile_pas.params"
#aas_tmplate="/sapmnt/$SAPSYSTEMNAME/$dirpath/inifile_aas.params"
swpmpath="/backup/software/swpm2"

lctr=0
prodvalctr=0
input_conf=$1
vsidadmuid=0
vsapsysgid=0
####################################################################################################################
if [ -z "$input_conf" ]  
then
        echo 'You missed passing config file details'
        exit
fi

echo $input_conf
if [ "$input_conf" == "conf.txt" ]
then 
echo 'You are fine to proceed'
    #exit
else
   echo " you entered wrong file $input_conf instead conf.txt"
    exit
fi

vsidadmuid=`grep -i shdadm /etc/passwd | cut -d : -f3`
vsapsysgid=`grep -i sapsys /etc/group | cut -d : -f3`
echo " Please maintain only  sidadm user UID details as $vsidadmuid and sapsys GID details as  $vsapsysgid only while prompted during input"
`sleep 2`
###################################################################################################################

#####################variable configuration#########################################################################
confpopulate(){
{ while read myline; do
object=`echo $myline | cut -d= -f1`
case $object in
SAPSYSTEMNAME)
sapsystemname=`echo $myline | cut -d= -f2`
#echo " $sapsystemname"
;;
DIRPATH)
dirpath=`echo $myline | cut -d= -f2`
#echo " $dirpath"
;;
REP_FILE)
rep_file=`echo $myline | cut -d= -f2 | sed -e "s/SAPSYSTEMNAME/$sapsystemname/g" | sed -e "s@DIRPATH@$dirpath@g" | xargs`
;;
PROD_FILE)
prod_file=`echo $myline | cut -d= -f2 | sed -e "s/SAPSYSTEMNAME/$sapsystemname/g" | sed -e "s@DIRPATH@$dirpath@g" | xargs`
;;
ASCS_TMPLATE)
ascs_tmplate=`echo $myline | cut -d= -f2 | sed -e "s/SAPSYSTEMNAME/$sapsystemname/g" | sed -e "s@DIRPATH@$dirpath@g" | xargs`
;;
DB_TMPLATE)
db_tmplate=`echo $myline | cut -d= -f2 | sed -e "s/SAPSYSTEMNAME/$sapsystemname/g" | sed -e "s@DIRPATH@$dirpath@g" | xargs`
;;
PAS_TMPLATE)
pas_tmplate=`echo $myline | cut -d= -f2 | sed -e "s/SAPSYSTEMNAME/$sapsystemname/g" |  sed -e "s@DIRPATH@$dirpath@g" | xargs`
;;
AAS_TMPLATE)
aas_tmplate=`echo $myline | cut -d= -f2 | sed -e "s/SAPSYSTEMNAME/$sapsystemname/g" |  sed -e "s@DIRPATH@$dirpath@g" | xargs`
;;
INSTANCE_NUMBER)
inst_number=`echo $myline | cut -d= -f2 | xargs`
;;
SAPINST_CWD)
sapinst_cwd=`echo $myline | cut -d= -f2 | xargs`
;;
esac
done } < $input_conf
}

##################################Original logic where list was pre-fed and populated value#####################

replacestringorig() {
#set -vx
         replabelctr=1
          repvaluectr=1
         # flgctr="N"
             { while read myline ; do 
                object=`echo "${lab[replabelctr]}"`
                echo "object = $object"
                #echo $myline
                labelstor=`echo $myline | cut -d= -f1`
              case $object in 
                $labelstor)
                 echo "Hello I am in casecondition"
                 tmpstore=`echo $myline | cut -d= -f2`
                 echo $tmpstore
                 echo "${varr[repvaluectr]}"
                 echo "${lab[replabelctr]}" 
                 `sed -i "s/$tmpstore/${varr[repvaluectr]}/g" "$rep_file"`
                  ((replabelctr=$replabelctr+1))
                  ((repvaluectr=$repvaluectr+1))
                   echo "replablectr value=$replabelctr"
                   echo "repvaluectr value=$repvaluectr"
                  ;;
                  esac
             done } < $rep_file

   }
#####################################################################################################################

mainmenu(){
while :
 do
 clear
 echo "----------------------------------------------"
 echo " * * * * * * * Main Menu * * * * * * * * * * "
 echo "----------------------------------------------"
 echo "[1] Install additional Application Server "
 echo "[2] Install Primary Application server"
 echo "[3] Install ASCS server"
 echo "[4] Install HANA Database instance"
 echo "[5] Install All Application install"
 echo "[6] Install multiple application instances"
 echo "[7] Exit"
 echo "----------------------------------------------"
echo -n "Enter your menu choice [1-7]:"
 read yourch
 case $yourch in
 1) echo "Install Additional APPlication server " ; additional_appserver;;
 2) echo "Install Primary Application server" ;  additional_primary;;
 3) echo "Install ASCS server" ; additional_ascs;;
 4) echo "Install HANA DB" ; additional_hana;;
 5) echo "Install All APP" ; allapp;;
 6) echo "Install multiple APP" ; multiapp;;
 7) exit 0 ;;
 *) echo "Opps!!! Please select choice [1-7]";
 echo "Press a key. . ." ; read ;;
esac

done

}
#########################################################################################
hostcheck(){
#set -vx
input_host="hosttemp.txt"

hostip=`hostname -i`
host=`hostname`
proceed="N"
#`grep -i $hostip "hostconf.txt" | grep -i $type > $input_host`
`grep -i $hostip "hostconf.txt" > $input_host`
{ while read hostline; do
installtype=`echo $hostline | awk -F '=' '{print$2}' | cut -d- -f2`
#echo $installtype
#echo $type
#echo "$installtype and $type"
if [ $installtype == $type ]
 then 
   proceed="Y"
  # exit
fi
#else
#  echo "Wrong Host selection for Installation"
#  exit
#fi   
done } < $input_host

#echo "Wrong Host selection for Installation"
}


##############################################################################################

templatecopy(){
#set -vx
echo "Your choice variable=$yourch"

case $yourch in  
1)
echo " Installation of Additional Application Server"
type="AAS"
hostcheck
if [[ "$proceed" == "Y" ]]
 then 
  #prod_id="NW_ABAP_DI:"
  prod_id="NW_DI:"
  `cp $aas_tmplate $rep_file`
  #`chmod 777 $rep_file` 
  `rm $rep_file$type`
`grep -v '#' $rep_file |grep "\S" >>$rep_file$type`
  `chmod 777 $rep_file$type` 
 
else
  echo "you cant do application server installation server on the $host" 
  exit
fi
;;

2)
echo " Installation of Primary Application Server"
type="PAS"
hostcheck
echo "proceed value= $proceed" 
#exit
if [[ "$proceed" == "Y" ]]
 then 
  prod_id="NW_ABAP_CI:"
  `cp $pas_tmplate $rep_file`
  `rm $rep_file$type`
  `grep -v '#' $rep_file |grep "\S" >>$rep_file$type`
else
  echo "you cant do primary application server Installation on the $host" 
  exit
fi
;;

3)
echo " Installation of ASCS Server"
type="ASCS"
hostcheck
if [[ "$proceed" == "Y" ]]
 then 
  prod_id="NW_ABAP_ASCS:"
  `cp $ascs_tmplate $rep_file`
   `rm $rep_file$type`
   `grep -v '#' $rep_file |grep "\S" >>$rep_file$type`
else
  echo "you cant do ASCS Installation server on the $host" 
  exit
fi
;;
4)
echo " Installation of DB Server"
type="DB"
hostcheck
if [[ "$proceed" == "Y" ]]
 then 
   prod_id="NW_ABAP_DB:"
   `cp $db_tmplate $rep_file` 
    `rm $rep_file$type`
   `grep -v '#' $rep_file |grep "\S" >>$rep_file$type`
else
  echo "you cant do Database server Installation on the $host" 
  exit
fi
;;
6)
echo " Installation of multiple Application Server"
type="AAS"
hostcheck
if [[ "$proceed" == "Y" ]] 
 then 
   if [[ "$loopctr" == 1 ]]
     then 
  #prod_id="NW_ABAP_DI:"
         #prod_id="NW_DI:"
         `cp $aas_tmplate $rep_file`
         `rm $rep_file$type`
         `grep -v '#' $rep_file |grep "\S" >>$rep_file$type`
          #exit
   fi
else
  echo "you cant do application server installation server on the $host" 
  exit
fi
esac
} 
#################################################################################################
################################populating values for label entries and values##########


storarr(){
echo " I am in storearrray"
labelctr=0
valctr=0
{ while read myline; do
    if [ -n "${myline}"  ]
     then
       varr[valctr]=`echo $myline | awk -F '=' '{print$2}'`
       lab[labelctr]=`echo $myline | awk -F '=' '{print$1}'`
       ((labelctr=$labelctr+1))
        ((valctr=$valctr+1))
    fi
done } < $rep_file$type 
}
##########################################################################################


#############################Accepting Input from user to populate new paramaters.##################################
readinput(){
#set -vx
lctr=0
echo " I am in readinput"
#lab=( "${lab[@]/#+([[:blank:]])/}" )
#varr=( "${varr[@]/#+([[:blank:]])/}" )
for y in "${lab[@]}"

 do
 {
   var=""
   echo "${lab[lctr]}"
   echo "${varr[lctr]}"
   read var
   if [[ $var = "" ]]; then
    varr[$lctr]=`echo ${varr[lctr]}| xargs`
    #varr[$lctr]=`grep(s/\s*$//g, ${varr[lctr]})`
    #varr[$lctr]= ${varr[lctr]/#+([[:blank:]])/}
   else
    varr[$lctr]=$var
   fi 
    if [ ${lab[lctr]} == $inst_number ]
  then
    prodvalctr=${varr[lctr]}
    echo "in the first installation $prodvalctr"
   fi 
   
   echo "entered value ${varr[lctr]}"
  ((lctr=$lctr+1))
   #echo "entered value ${varr[lctr]}"
 }
 done
#return $var
}
#########################################################################################################################
readinput1(){
lctr=0
flag="Y"
    var=""
   echo "${lab[lctr]}"
   echo "${varr[lctr]}"
   #read var
while [ $flag == "Y" ]
do
 if [ ${lab[lctr]} == $inst_number ]
  then  
 {
   var=${varr[lctr]}
   ((var=$var+1))
    if [[ $var -le 9 ]]
    then 
      var=("0"$var)
       varr[$lctr]=$var
    else 
      varr[$lctr]=$var
    fi 
   echo "entered value ${varr[lctr]}"
   prodvalctr=${varr[lctr]}
   ((flag='N'))
 }
 else 
  ((lctr=$lctr+1))
 fi 
done
#return $var
}
 
#########################################################
## Original code backup, this functional module was having limitation to check first entry as instance number which required to be avoided as entry
## can be anywhere in the template####
#readinput1(){
##lctr=0
#   var=""
#   echo "${lab[lctr]}"
#   echo "${varr[lctr]}"
   #read var
#   var=${varr[lctr]}
#   ((var=$var+1))
#    if [[ $var -le 9 ]]
#    then 
#      var=("0"$var)
#       varr[$lctr]=$var
#    else 
#      varr[$lctr]=$var
#    fi 
#   echo "entered value ${varr[lctr]}"
#   #echo "entered value ${varr[lctr]}"
# }
#########################################################







#######################################################################################################################

replacestring() {
   #set -vx
         replabelctr=0
          repvaluectr=0
             { while read myline ; do
                object=`echo "${lab[replabelctr]}"`
                echo "object = $object"
                labelstor=`echo $myline | cut -d= -f1`
              case $object in
                 $labelstor)
                tmpstore=`echo $myline | cut -d= -f2-`
          
                slashchk=`echo $tmpstore | cut -b 1,1`
                  if [ $slashchk == "/" ]
                  then
                    `sed -i "/$labelstor/s@=.*@=@g" "$rep_file$type"` 
                   # `sed -i "s@$tmpstore@  @g" "$rep_file$type"` 
                    `sed -i "s@$labelstor=@$labelstor=\ \${varr[repvaluectr]}@g" "$rep_file$type"` 
                  else
                     echo "labelstor=$labelstor"
                     echo "tmpstore=$tmpstore"
                    `sleep 1`
                    #`sed -i "/$labelstor/s/$tmpstore/ /g" "$rep_file$type"` 
                    `sed -i "/$labelstor/s/=.*/=/g" "$rep_file$type"` 
                    `sed -n 'p' "$rep_file$type" >> trial.txt`  
                   `sed -i "s/$labelstor=/$labelstor=\ \${varr[repvaluectr]}/" "$rep_file$type"` 
                    `sed -n 'p' "$rep_file$type" >> trial2.txt`
                    #`sed -i "s\$labelstor=\$labelstor=\ \${varr[repvaluectr]}/g" "$rep_file$type"` 
                   #`cat "$rep_file$type"` 
                  fi
                     #if [[ $repvaluectr == 10 ]]
                     #then 
                     # exit
                    # fi
                  ((replabelctr=$replabelctr+1))
                  ((repvaluectr=$repvaluectr+1))
                  ;;
                  esac
             done } < $rep_file$type
               # `sed -i "/^[[:blank:]]*$/ d" $rep_file$type`
   }
##############################################################################################################################
installapp() {
#prodvalctr=$var
#echo $prodvalctr
#exit
varsapinst_skip_dialogs=true
varsapinst_start_guiserver=false
varsapinst_input_parameters_url=$rep_file$type
#varSAPINST_EXECUTE_PRODUCT_ID=$prod_id
#varSAPINST_CWD=/backup/temp_sapinst/"$type$prodvalctr"
varSAPINST_CWD="$sapinst_cwd"/"$type$prodvalctr"
`mkdir "$varSAPINST_CWD"`
 ownership=root:sapinst
 perm="777"
`chown "$ownership" "$varSAPINST_CWD"`
`chmod "$perm" "$varSAPINST_CWD"`
`cp $rep_file$type $rep_file$type$prodvalctr`
inststr="/sapinst SAPINST_INPUT_PARAMETERS_URL=$rep_file$type$prodvalctr SAPINST_EXECUTE_PRODUCT_ID=$varSAPINST_EXECUTE_PRODUCT_ID SAPINST_SKIP_DIALOGS=$varsapinst_skip_dialogs SAPINST_START_GUISERVER=$varsapinst_start_guiserver SAPINST_CWD=$varSAPINST_CWD"
echo "$inststr"
#`$swpmpath$inststr`
#./$inststr
}

menusel(){
echo "======================Enter a choice for product-id selection ====================================="
select prod; do
if [ 1 -le "$REPLY" ] && [ "$REPLY" -le $# ];
then
echo "The selected Instance option is $prod"
varSAPINST_EXECUTE_PRODUCT_ID="$prod"
#varSAPINST_EXECUTE_PRODUCT_ID="$prod"
break;
else
echo "$REPLY"
exit
echo "Wrong selection: Select any number from 1-$#"
fi
done
}
#==============================================================
#}
menu_from_array(){
prodctr=0
{ while read myline; do
       prodid[prodctr]=`echo $myline | awk -F '=' '{print$1}'`
       ((prodctr=$prodctr+1))
done } < $prod_file
menusel "${prodid[@]}"
}


############################################################################################################################3333
additional_appserver(){
templatecopy
storarr
readinput
replacestring
menu_from_array
installapp
}
#######################################################################################################################

additional_primary(){
templatecopy
storarr
readinput
replacestring
menu_from_array
installapp
}

##########################################################################################################################

additional_ascs(){
templatecopy
storarr
readinput
replacestring
menu_from_array
installapp
}

#########################################################################################################################


additional_hana(){
templatecopy
storarr
readinput
replacestring
menu_from_array
installapp
}
#######################################################################################################################

allapp(){
#set -vx
allappch=1
yourch=1
     while [ $allappch -le 4 ] 
     echo "All choice value is $allappch"
     do
        #hostchk
        templatecopy
        storarr
        readinput
        replacestring
        menu_from_array
        installapp
        ((yourch=$yourch+1))
        ((allappch=$allappch+1))
    done  
}

##################################################################################################################

multiapp(){
#set -vx
loopctr=1
echo " Enter Number of additional application Instances planned to Install"
read instnum
#instnum=`grep -i DI hostdiaconf.txt |wc -l`
     while [ $loopctr -le $instnum ] 
     do
         if [ $loopctr == 1 ]
          then 
            templatecopy
            storarr
            readinput
            replacestring
            menu_from_array 
            installapp
         else
            templatecopy
            readinput1
            replacestring
            installapp
         fi
        ((loopctr=$loopctr+1))
    done  
}
####################################################################################################################

confpopulate
mainmenu


