#!/bin/bash
#set -vx
response=$(curl -q "https://dev191809.service-now.com/api/now/table/incident" \
--request POST \
--header "Accept:application/json" \
--header "Content-Type:application/json" \
--data "{\"short_description\":\"This is demo\",\"priority\":\"3\"}" \
--user 'akash':'Lenovo@0727')

sys_id=`echo "$response" | sed -n 's/.*"sys_id":"\([^"]*\)".*/\1/p'`
send_attachment(){
curl -q "https://dev191809.service-now.com/api/now/attachment/file?table_name=incident&table_sys_id="$sys_id"&file_name="$2"" \
        --request POST \
        --header "Content-Type: application/json" \
        --user "akash":"Lenovo@0727" \
        --data-binary @$1
}

send_attachment $1 "Raw"
send_attachment $2 "GenAI"
