
#API_KEY="be150cafe27545caae89ad6f2d1d8172"
#ENDPOINT="https://genai-openai-gimsc.openai.azure.com"
#DEPLOYMENT_NAME="IMSC-GenAI-gpt-35-turbo-16k"
#API_VERSION="2023-03-15-preview"

source ./genaiconf.txt

if [ $genai = "true" ] 
then
# Input prompt for OpenAI
PROMPT="What is Authorozation object s_tcode mean"
echo "$1"

# Create JSON payload
PAYLOAD=$(cat <<EOF
{
  "messages": [
    {"role": "system", "content": "You are a SAP Expert."},
    {"role": "user", "content": "$1"}
  ],
  "max_tokens": 500
}
EOF
)

# Make the API request
RESPONSE=$(curl -s -X POST "$ENDPOINT/openai/deployments/$DEPLOYMENT_NAME/chat/completions?api-version=$API_VERSION" \
  -H "Content-Type: application/json" \
  -H "api-key: $API_KEY" \
  -d "$PAYLOAD")

# Extract and print the response
echo "Response from OpenAI:"
echo $RESPONSE
echo $RESPONSE >> output.txt
fi
