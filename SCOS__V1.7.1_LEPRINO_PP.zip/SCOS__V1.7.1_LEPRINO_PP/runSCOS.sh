#!/bin/bash
#set -x

###################################################################
#Script Name    :runSCOS
#Description    :Execute SCOS.sh
#Args           :Credential to run SCOS
#Author         :Soumik Roy Chowdhury
#Email          :soumik-roy.chowdhury@cagemini.com
###################################################################

unzip SCOS.zip

if [ -d "SCOS" ] 
then
	echo "Done: User Authentication Successfull."
	`mv SCOS/* .`
	`mv license.txt .license.txt`
	`rm -rf SCOS`
	/bin/bash SCOS.sh
	`rm -rf SCOS.sh exp_tab.sh imp_tab.sh TOPTABLES.sh bdls.sh BDLS_TABLES_ALL.txt BDLS_TABLES_TOP.txt BDLS_FIELDS_ALL.txt TABLES_PARTITION.txt BDLS_TABLES_EXE.txt BDLS_TABLES_PARTITION.txt BDLS_TABLES_NON_PARTITION.txt cols.txt partitionDetails.txt sqlexe.sh bdlsindx.sh createBDLSdefault.sh bdlstabexcl.sh massimport.sh .license.txt fetchdeltatr.sh crtabsqlexe.sh othtabsqlexe.sh` 
else
	echo "Error: User Authentication Failed."
fi
